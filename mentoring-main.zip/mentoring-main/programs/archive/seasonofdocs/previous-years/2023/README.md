
Accepted CNCF projects for GSOD 2023 are :

| Organization Name                                | GSOD Page                                                                         | Budget                                                                                        | Accepted Project Proposal                                                                         |
|--------------------------------------------------|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
| [Flux](https://github.com/fluxcd)                | [Flux GSoD page](https://fluxcd.io/contributing/docs/google-season-of-docs-2023/) | [Flux Budget](https://fluxcd.io/contributing/docs/google-season-of-docs-2023/#project-budget) | [Improving the Flux User Onramp](https://fluxcd.io/contributing/docs/google-season-of-docs-2023/) |
| [WasmEdge](https://github.com/WasmEdge/WasmEdge) | [WasmEdge GSoD page](https://github.com/WasmEdge/GSoD2023)                        | [WasmEdge Budget](https://github.com/WasmEdge/GSoD2023#project-budget)                        | [Reorganize the contributor guide](https://github.com/WasmEdge/GSoD2023)                          |

