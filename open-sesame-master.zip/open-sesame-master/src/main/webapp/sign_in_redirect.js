import {authRedirect} from './js-build/auth_check.js';

authRedirect('/', '/dashboard.html', '/signup.html');
