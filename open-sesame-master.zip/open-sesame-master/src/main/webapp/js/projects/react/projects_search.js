import {ProjectsSearch} from './components/ProjectsSearch.js';

const projectsContainer = document.getElementById('projects-container');
ReactDOM.render(<ProjectsSearch />, projectsContainer);
